package DFS_BFS;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ������ȣ���̱� {

	static int c;
	static boolean ch[]=new boolean[1001];
	static boolean line[][]=new boolean[1001][1001];
	static int house[][]=new int[1001][1001];
	static int ct=0;
	static int cnt=0;
	static ArrayList<Integer> arr=new ArrayList<>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		c=scan.nextInt();
		
		for (int i = 1; i <= c; i++) {
			String input=scan.next();
			for (int j = 1; j <= c; j++) {
				house[i][j]=input.charAt(j-1)-'0';
			}
		}
		
		for (int i = 1; i <= c; i++) {
			for (int j = 1; j <= c; j++) {
				System.out.print(house[i][j]);
			}
			System.out.println();
		}
		
//		scan.nextLine();
//		for (int i = 1; i <= c; i++) {
//			String s=scan.next();
//			for (int j = 1; j <= c; j++) {
//				house[i][j]=Integer.parseInt(s.substring(j-1,j));
//			}
//		}
		
		for (int i = 1; i <= c; i++) {
			for (int j = 1; j < c; j++) {
				if(house[i][j]==house[i][j+1] && house[i][j+1]==1) {
					line[(i-1)*c+j][(i-1)*c+j+1]=true;
					line[(i-1)*c+j+1][(i-1)*c+j]=true;
				}
			}
		}
		
		for (int i = 1; i <= c; i++) {
			for (int j = 1; j < c; j++) {
				if(house[j][i]==house[j+1][i] && house[j+1][i]==1) {
					line[(j-1)*c+i][j*c+i]=true;
					line[j*c+i][(j-1)*c+i]=true;
				}
			}
		}
		
		for (int i = 1; i <= c*c; i++) {
			ct=0;
			ch[i]=true;
			dfs(i);
			if(ct>1) {
				cnt++;
				arr.add(ct);
			}
		}
		
		System.out.println(cnt);
		Collections.sort(arr);
		for (int i = 0; i < arr.size(); i++) {
			System.out.println(arr.get(i));
		}
	}
	
	static void dfs(int num) {
		ct++;
		for (int i = 1; i <= c*c; i++) {
			if(line[num][i] && !ch[i]) {
				ch[i]=true;
				dfs(i);
			}
		}
	}

}
